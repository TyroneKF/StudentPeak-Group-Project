# StudentPeak

- A social media app exclusive to students

GitHub repository: 

https://github.com/nikodemzareba/StudentPeak

Basic wireframe:

https://xd.adobe.com/view/75ac363e-89dc-4662-a601-a609904c584f-20ff/

Group One members:

Nikodem Zareba - nz76@kent.ac.uk 
Aleksej Bratkovskij - ab2323@kent.ac.uk
Osagie Ehigiamusoe - oce3@kent.ac.uk
Devika Vasisht - dv217@kent.ac.uk

Group Two members:

Tyrone Friday - tf289@kent.ac.uk
Nicole Akanbi - na499@kent.ac.uk
Israel Adekunle - ia271@kent.ac.uk
Ayodeji Fasuba - aof5@kent.ac.uk
