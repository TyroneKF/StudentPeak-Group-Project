import {Text} from "react-native";
import React from "react";

export const B = (props) => <Text style={{fontWeight: 'bold'}}>{props.children}</Text>