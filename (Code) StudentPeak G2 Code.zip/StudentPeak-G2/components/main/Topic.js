import React from 'react'
import { View, Text } from 'react-native'
//import Topbar from './top/Topbar';

export default function Topic() {
    return (
        <View>
            {/*Shows you what page you're on */}
            <Text>Topic</Text>
        </View>
    )
}
