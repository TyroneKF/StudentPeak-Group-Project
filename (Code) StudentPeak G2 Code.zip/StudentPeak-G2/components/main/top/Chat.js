import React from 'react'
import { View, Text } from 'react-native'

export default function Chat() {
    return (
        <View>
        <Text>Chat screen</Text>
        </View>
    )
}