import React from 'react'
import { View, Text } from 'react-native'

export default function Meet() {
    return (
        <View>
            <Text>Meet screen</Text>
        </View>
    )
}
